<?php
define('FCM_SERVER_KEY', 'YOUR_FCM_SERVER_KEY'); // Paste your server key here
define('FIREBASE_DB_URL', 'https://erdmt-64c80-default-rtdb.firebaseio.com/');
define('FIRESTORE_PROJECT_ID', 'erdmt-64c80');
?>